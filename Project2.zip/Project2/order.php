
<!DOCTYPE HTML>  
<html>
<head>
    <title>EDC Knife Supply</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="stylesheet.css">
    <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    <script type="text/JavaScript" src ="form_validation.js"></script>
</head>
<body>  

<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$pdo = new PDO("mysql:host=$servername;dbname=knives", $username, $password);

$fname = $lname = $email = $street = $city = $state = $zip = $item = $quantity = $ship = $card_num = $cvv = "";


function validate_input($input){
    $input = trim($input);
    $input = stripslashes($input);
    $input = htmlspecialchars($input);
    return $input;
}
?>

    <section class="content_box">
        <img id="banner" src="images/banner.png" alt ="Banner"/>
        <ul class="nav_bar">
            <li class="left_nav"><a href="index.php">HOME</a></li>
            <li class="left_nav"><a href="about.html">ABOUT</a></li>
            <li class="left_nav"><a href="brands.html">BRANDS</a></li>
            <li class="left_nav"><a href="order.php">ORDER</a></li>
            <li class="left_nav"><a href="contact.html">CONTACT</a></li>
            <li class="right_nav"><a href="#">CART</a></li>
        </ul>
        
        <div class="main_content">
            <h1>ORDER</h1>
            <h4>Order Form</h4>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                <table style="border-spacing: 10px;">
                    <tr>
                        <td>First Name:</td>
                        <td><input type="text" name="fname" autofocus></td>
                    </tr>
                    <tr>
                        <td>Last Name:</td>
                        <td><input type="text" name="lname"></td>
                    </tr>
                    <tr>
                        <td>Email: </td>
                        <td><input type="text" name="email"></td>
                    </tr>
                    <tr>
                        <td>Street: </td>
                        <td><input type="text" name="street"></td>
                    </tr>
                    <tr>
                        <td>Zip Code: </td>
                        <td><input type="text" name="zip" onblur="getCityState(this.value)"/></td>
                    </tr>
                    <tr>
                        <td>City: </td>
                        <td><input type="text" name="city"></td>
                    </tr>
                    <tr>
                        <td>State: </td>
                        <td><input type="text" name="state"></td>
                    </tr>
                    
                    <tr>
                        <td>Item: </td>
                        <td><input type="text" name="item"></td>
                    </tr>
                    <tr>
                        <td>Quantity: </td>
                        <td><input type="number" name="quantity" size="2" min="1" style="width: 30%;"></td>
                    </tr>
                    <tr>
                        <td>Shipping Method: </td>
                        <td><select name="ship">
                                <option value="flatrate">USPS Flat Rate</option>
                                <option value="ground">UPS Ground</option>
                                <option value="nextday">UPS Next-Day</option>
                            </select></td>
                    </tr>
                    <tr>
                        <td>Credit/Debit Card: </td>
                        <td><input type="text" name="card_num"></td>
                    </tr>
                    <tr>
                        <td>CVV: </td>
                        <td><input type="text" name="cvv"></td>
                    </tr>
                </table>
                <input type="submit" class="sub_button" value="Submit" name="sub"/>
            </form>
        </div>
        <div class="sidebar_div">
            <ul>
                <li class="side_items_top">BRANDS</li>
                <li class="side_items"><a href="#">Benchmade</a></li>
                <li class="side_items"><a href="#">Spyderco</a></li>
                <li class="side_items"><a href="#">Chris Reeve</a></li>
                <li class="side_items"><a href="#">Boker Plus</a></li>
                <li class="side_items"><a href="#">Gravelle</a></li>
                <li class="side_items"><a href="#">White River</a></li>
                <li class="side_items"><a href="#">Zero Tolerance</a></li>
                <li class="side_items"><a href="#">Bradford</a></li>
            </ul>
        </div>   
        </section>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $fname = validate_input($_POST["fname"]);
    $lname = validate_input($_POST["lname"]);
    $email = validate_input($_POST["email"]);
    $street = validate_input($_POST["street"]);
    $city = validate_input($_POST["city"]);
    $state = validate_input($_POST["state"]);
    $zip = validate_input($_POST["zip"]);
    $item = validate_input($_POST["item"]);
    $quantity = validate_input($_POST["quantity"]);
    $ship = validate_input($_POST["ship"]);
    $card_num = validate_input($_POST["card_num"]);
    $cvv = validate_input($_POST["cvv"]);
    }

    if(isset($_POST['fname'])){
        $message = "Order for $item successfully created";
        echo '<script type="text/javascript">alert($message)</script>';
        $sql = "INSERT INTO orders (fname,lname,email,street,city,state,zip,item,quantity,ship,card_num,cvv) VALUES (:fname,:lname,:email,:street,:city,:state,:zip,:item,:quantity,:ship,:card_num,:cvv)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array(
            ':fname'=>$_POST['fname'],
            ':lname'=>$_POST['lname'],
            ':email'=>$_POST['email'],
            ':street'=>$_POST['street'],
            ':city'=>$_POST['city'],
            ':state'=>$_POST['state'],
            ':zip'=>$_POST['zip'],
            ':item'=>$_POST['item'],
            ':quantity'=>$_POST['quantity'],
            ':ship'=>$_POST['ship'],
            ':card_num'=>$_POST['card_num'],
            ':cvv'=>$_POST['cvv']));
        
    }
    ?>
</body>
</html>
