/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

function getCityState(zip){
    var req = new XMLHttpRequest();
    req.onreadystatechange = function(){
        if (req.readyState == 4 && req.status == 200) {
            var response = req.responseText;
            var loc = response.split(", ");
            if(document.getElementById("city").value == ""){
                document.getElementById("city").value = loc[0];
            }
            if(document.getElementById("state").value == ""){
                document.getElementById("state").value = loc[1];
            }
        }
    }
    xhr.open("POST", "getCityState.php", true);
    xhr.setRequestHeader("content-type", "application/x-www-form-urlencoded");
    xhr.send("zip=" + zip);
    
}
