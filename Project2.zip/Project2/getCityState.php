<?php
    $file = fopen("zip_codes.csv","r");
    $cityState = array();
    while(! feof($file))
    {
    $line = fgetcsv($file);
    $tempVal = "".$line[2].", ".$line[1];
    $cityState[$line[0]] = $tempVal;
    }
    fclose($file);
    $zip = $_GET['zip'];
    if(array_key_exists($zip, $cityState)){
        print($cityState[$zip]);
    }
    else {
        print(' , ');
    }           
?>


