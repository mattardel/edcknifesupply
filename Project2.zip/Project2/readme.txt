URL: http://andromeda-9.ics.uci.edu:5120/index.php

Put PA1 in Project 1 folder for reference.
Website navigates through clicking on Brands, then ordering using the product name in the Order page.
Attempted to add in PHP and Ajax on Order page. Was unable to dynamically generate PHP.
Created database with 2 tables - specs and orders. Used phpMyAdmin to generate these. SQL queries done in PHP files.
Database included in knives folder.
