<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title>EDC Knife Supply</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" type="text/css" href="stylesheet.css">
        <link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">
    </head>
    <body>
        <section class="content_box">
            <img id="banner" src="images/banner.png" alt ="Banner"/>
            <ul class="nav_bar">
                <li class="left_nav"><a href="index.php">HOME</a></li>
                <li class="left_nav"><a href="about.html">ABOUT</a></li>
                <li class="left_nav"><a href="brands.html">BRANDS</a></li>
                <li class="left_nav"><a href="order.php">ORDER</a></li>
                <li class="left_nav"><a href="contact.html">CONTACT</a></li>
                <li class="right_nav"><a href="#">CART</a></li>
            </ul>
            
            <div class="main_content">
                <h1>ABOUT</h1>
                <p style="padding-bottom: 2%;">Welcome to EDC Knife Supply! Here you will find a variety of
                everyday carry folding and fixed blade knives to complement your
                current array of items you carry daily. We carry many popular, 
                high-quality brands coming from multiple countries. All are tested
                for build quality and usability. Feel free to talk to us by using
                the CONTACT tab!</p>
                <img src="images/_MG_2325-1.jpg" alt="Gravelle PCP" style="max-width: 96%; max-height: 100%; display: block; margin-left: 1%;">
            </div>
            
            <div class="sidebar_div">
                <ul>
                    <li class="side_items_top">BRANDS</li>
                    <li class="side_items"><a href="benchmade.html">Benchmade</a></li>
                    <li class="side_items"><a href="spyderco.html">Spyderco</a></li>
                    <li class="side_items"><a href="chrisreeve.html">Chris Reeve</a></li>
                    <li class="side_items"><a href="bokerplus.html">Boker Plus</a></li>
                    <li class="side_items"><a href="gravelle.html">Gravelle</a></li>
                    <li class="side_items"><a href="whiteriver.html">White River</a></li>
                    <li class="side_items"><a href="zerotolerance.html">Zero Tolerance</a></li>
                    <li class="side_items"><a href="bradford.html">Bradford</a></li>
                </ul>
            </div>
        
            
        </section>
    </body>
</html>
